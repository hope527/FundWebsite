$(function () {
    $("#form").validate();
});
